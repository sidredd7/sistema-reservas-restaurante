// db.config.js
module.exports = {
    user: 'postgres',       // Assumindo que o usuário é 'postgres'
    host: 'localhost',
    database: 'dados-reservas',
    password: '135579',   // A senha que você forneceu
    port: 5432,
  };